class Mappings:
    def __init__(self):
        self.mappings = {
            "AMIMap":
                {
                    "cn-northwest-1": {
                        "AMI": "ami-09478b31d8343756c",
                    }
                }
        }
